﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pixels_폼만_
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void picOrg_MouseMove(object sender, MouseEventArgs e)
        {
            Bitmap bitmap = (Bitmap)picOrg.Image;
            Color col = bitmap.GetPixel(e.X, e.Y);
            picColor.BackColor = col;
            lblRed.Text = "Red : " + Convert.ToString(col.R);
            lblGreen.Text = "Green : " + Convert.ToString(col.G);
            lblBlue.Text = "Blue : " + Convert.ToString(col.B);
        }

        private void btnReadFile_Click(object sender, EventArgs e)
        {
            DialogResult res = openFileDialog1.ShowDialog();
            if (res == DialogResult.OK)
            {
                string fname = openFileDialog1.FileName;
                picOrg.Load(fname);
            }
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            Bitmap bmapOrg = (Bitmap)picOrg.Image;
            Bitmap bmapTrg = new Bitmap(bmapOrg.Width, bmapOrg.Height);

            Color col;
            int red, green, blue;
            for (int i = 0; i < bmapOrg.Width; i++)
            {
                for (int j = 0; j < bmapOrg.Height; j++)
                {
                    col = bmapOrg.GetPixel(i, j);
                    red = col.R;
                    green = col.G;
                    blue = col.B;
                    bmapTrg.SetPixel(i, j, Color.FromArgb(red, green, blue));
                }
            }
            picTrg.Image = bmapTrg;
        }

        private void btnReverse_Click(object sender, EventArgs e)
        {
            Bitmap bmapOrg = (Bitmap)picOrg.Image;
            Bitmap bmapTrg = new Bitmap(bmapOrg.Width, bmapOrg.Height);

            Color col;
            int red, green, blue;
            for (int i = 0; i < bmapOrg.Width; i++)
            {
                for (int j = 0; j < bmapOrg.Height; j++)
                {
                    col = bmapOrg.GetPixel(i, j);
                    red = 255 - col.R;
                    green = 255 - col.G;
                    blue = 255 - col.B;
                    bmapTrg.SetPixel(i, j, Color.FromArgb(red, green, blue));
                }
            }
            picTrg.Image = bmapTrg;
        }

        private void btnMirrorLR_Click(object sender, EventArgs e)
        {
            Bitmap bmapOrg = (Bitmap)picOrg.Image;
            Bitmap bmapTrg = new Bitmap(bmapOrg.Width, bmapOrg.Height);

            Color col;
            int red, green, blue;
            for (int i = 0; i < bmapOrg.Width; i++)
            {
                for (int j = 0; j < bmapOrg.Height; j++)
                {
                    col = bmapOrg.GetPixel(i, j);
                    red = col.R;
                    green = col.G;
                    blue = col.B;
                    bmapTrg.SetPixel(bmapOrg.Width - i - 1, j, Color.FromArgb(red, green, blue));
                }
            }
            picTrg.Image = bmapTrg;
        }

        private void btnGray_Click(object sender, EventArgs e)
        {
            int threshold = hScrollBar1.Value;

            Bitmap bmapOrg = (Bitmap)picOrg.Image;
            Bitmap bmapTrg = new Bitmap(bmapOrg.Width, bmapOrg.Height);

            Color col;
            int red, green, blue;
            for (int i = 0; i < bmapOrg.Width; i++)
            {
                for (int j = 0; j < bmapOrg.Height; j++)
                {

                    col = bmapOrg.GetPixel(i, j);
                    red = col.R;
                    green = col.G;
                    blue = col.B;
                    /*int avr =
                        (int)(0.299 * red + 0.587 * green + 0.114 * blue);  //NTSC에서*/
                    int avr = (red + green + blue) / 3;     // 쉬운방법
                    bmapTrg.SetPixel(i, j, Color.FromArgb(avr, avr, avr));
                }
            }
            picTrg.Image = bmapTrg;
        }

        private void btnBin_Click(object sender, EventArgs e)
        {

            if (picTrg.Image == null) return;

            int threshold = hScrollBar1.Value;

            Bitmap bmapTrg = (Bitmap)picTrg.Image;
            Bitmap bmapBin = new Bitmap(bmapTrg.Width, bmapTrg.Height);

            Color col;
            int red, green, blue;
            for (int i = 0; i < bmapTrg.Width; i++)
            {
                for (int j = 0; j < bmapTrg.Height; j++)
                {
                    col = bmapTrg.GetPixel(i, j);
                    red = col.R;
                    green = col.G;
                    blue = col.B;
                    int avr = (red + green + blue) / 3;

                    int intensity = (avr >= threshold) ? 255 : 0;
                    bmapBin.SetPixel(i, j, Color.FromArgb(intensity, intensity, intensity));

                }
            }
            picBin.Image = bmapBin;



        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            lblScroll.Text = Convert.ToString(hScrollBar1.Value);
            btnBin.PerformClick();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

        }
    }
}
